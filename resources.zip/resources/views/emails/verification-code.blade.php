<h2>Verify Your Email to Continue Registration</h2>
<p>Thank you for starting registration. To continue, please verify your email.</p>
<p>Your verification code is: <strong>{{ $code }}</strong></p>
<p>Enter this code in the app to continue to the registration page.</p>
