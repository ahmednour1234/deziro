<!DOCTYPE html>
<html>
<head>
    <title> Code</title>
</head>
<body>

    <p>Your code is: {{ $code }}</p>
</body>
</html>
